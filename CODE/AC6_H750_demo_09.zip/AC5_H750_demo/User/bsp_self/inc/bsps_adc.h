#ifndef __BSPS_ADC_H
#define __BSPS_ADC_H


extern uint16_t ADCxValues[1024];
extern __IO uint8_t dma_flag;

void bsps_sample_test(void);
void bsps_adc_init(void);
void bsps_adc_sample_start(void);



#endif


