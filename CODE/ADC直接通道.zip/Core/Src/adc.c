/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    adc.c
  * @brief   This file provides code for the configuration
  *          of the ADC instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "adc.h"

/* USER CODE BEGIN 0 */
#include "stdio.h"
#include "tim.h"

#define sample_counts 128

__IO uint8_t dma_flag = 0;
uint16_t i = 0;

ALIGN_32BYTES(__attribute__((section (".RAM_D3"))) uint8_t ADC_ConvertedValue[sample_counts]);

/* USER CODE END 0 */

ADC_HandleTypeDef hadc3;
DMA_HandleTypeDef hdma_adc3;

/* ADC3 init function */
void MX_ADC3_Init(void)
{

  /* USER CODE BEGIN ADC3_Init 0 */

  /* USER CODE END ADC3_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC3_Init 1 */

  /* USER CODE END ADC3_Init 1 */

  /** Common config
  */
  hadc3.Instance = ADC3;
  hadc3.Init.Resolution = ADC_RESOLUTION_8B;
  hadc3.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc3.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc3.Init.LowPowerAutoWait = DISABLE;
  hadc3.Init.ContinuousConvMode = DISABLE;
  hadc3.Init.NbrOfConversion = 1;
  hadc3.Init.DiscontinuousConvMode = DISABLE;
  hadc3.Init.ExternalTrigConv = ADC_EXTERNALTRIG_T6_TRGO;
  hadc3.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_RISING;
  hadc3.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_ONESHOT;
  hadc3.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
  hadc3.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
  hadc3.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc3) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_0;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  sConfig.OffsetSignedSaturation = DISABLE;
  if (HAL_ADC_ConfigChannel(&hadc3, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC3_Init 2 */

  /* USER CODE END ADC3_Init 2 */

}

void HAL_ADC_MspInit(ADC_HandleTypeDef* adcHandle)
{

  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};
  if(adcHandle->Instance==ADC3)
  {
  /* USER CODE BEGIN ADC3_MspInit 0 */

  /* USER CODE END ADC3_MspInit 0 */

  /** Initializes the peripherals clock
  */
    PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_ADC;
    PeriphClkInitStruct.PLL2.PLL2M = 25;
    PeriphClkInitStruct.PLL2.PLL2N = 400;
    PeriphClkInitStruct.PLL2.PLL2P = 8;
    PeriphClkInitStruct.PLL2.PLL2Q = 2;
    PeriphClkInitStruct.PLL2.PLL2R = 2;
    PeriphClkInitStruct.PLL2.PLL2RGE = RCC_PLL2VCIRANGE_0;
    PeriphClkInitStruct.PLL2.PLL2VCOSEL = RCC_PLL2VCOWIDE;
    PeriphClkInitStruct.PLL2.PLL2FRACN = 0.0;
    PeriphClkInitStruct.AdcClockSelection = RCC_ADCCLKSOURCE_PLL2;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
    {
      Error_Handler();
    }

    /* ADC3 clock enable */
    __HAL_RCC_ADC3_CLK_ENABLE();

    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**ADC3 GPIO Configuration
    PC2_C     ------> ADC3_INP0
    */
    HAL_SYSCFG_AnalogSwitchConfig(SYSCFG_SWITCH_PC2, SYSCFG_SWITCH_PC2_OPEN);

    /* ADC3 DMA Init */
    /* ADC3 Init */
    hdma_adc3.Instance = BDMA_Channel0;
    hdma_adc3.Init.Request = BDMA_REQUEST_ADC3;
    hdma_adc3.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc3.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc3.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc3.Init.PeriphDataAlignment = DMA_PDATAALIGN_BYTE;
    hdma_adc3.Init.MemDataAlignment = DMA_MDATAALIGN_BYTE;
    hdma_adc3.Init.Mode = DMA_NORMAL;
    hdma_adc3.Init.Priority = DMA_PRIORITY_LOW;
    if (HAL_DMA_Init(&hdma_adc3) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(adcHandle,DMA_Handle,hdma_adc3);

  /* USER CODE BEGIN ADC3_MspInit 1 */

  /* USER CODE END ADC3_MspInit 1 */
  }
}

void HAL_ADC_MspDeInit(ADC_HandleTypeDef* adcHandle)
{

  if(adcHandle->Instance==ADC3)
  {
  /* USER CODE BEGIN ADC3_MspDeInit 0 */

  /* USER CODE END ADC3_MspDeInit 0 */
    /* Peripheral clock disable */
    __HAL_RCC_ADC3_CLK_DISABLE();

    /* ADC3 DMA DeInit */
    HAL_DMA_DeInit(adcHandle->DMA_Handle);
  /* USER CODE BEGIN ADC3_MspDeInit 1 */

  /* USER CODE END ADC3_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */

void Start_DMA_ADC(void)
{
	if (HAL_TIM_Base_Start(&htim6) != HAL_OK)
	{
		Error_Handler();
	}
	if(HAL_ADC_Start_DMA(&hadc3, (uint32_t *)ADC_ConvertedValue, sample_counts) != HAL_OK)
	{
		Error_Handler();
	}	
}



void sample_data(void)
{
	uint32_t values;
	float  temp;
	
	/* ��ǰDMA�����Ǻ������壬��ȡǰ��������ǰ4����ֵ��ƽ�� */
	if(dma_flag)
	{
		__set_PRIMASK(1);
		for(i = 0;i < sample_counts;i++)
		{
			printf("%.3f\r\n",ADC_ConvertedValue[i] * 3.3f / 256.0f);
		}
		dma_flag = 0;
		__set_PRIMASK(0);
//		HAL_ADC_Stop_DMA(&hadc1);
		HAL_TIM_Base_Stop(&htim6);
	}
}
void DMA1_Stream0_IRQHandler(void)
{
	/* ��������ж� */
	if((DMA1->LISR & DMA_FLAG_TCIF0_4) != RESET)
	{
		/*
		   1��ʹ�ô˺���Ҫ�ر�ע�⣬��1��������ַҪ32�ֽڶ��룬��2������Ҫ��32�ֽڵ���������
		   2�����봫������жϣ���ǰDMA����ʹ�û�������ǰ�벿�֣��û����Բ�����벿�֡�
		*/
		SCB_CleanInvalidateDCache();
		
		dma_flag = 1;
		
		/* �����־ */
		DMA1->LIFCR = DMA_FLAG_TCIF0_4;
	}

/* �봫������ж� */    
	if((DMA1->LISR & DMA_FLAG_HTIF0_4) != RESET)
	{
		/*
		   1��ʹ�ô˺���Ҫ�ر�ע�⣬��1��������ַҪ32�ֽڶ��룬��2������Ҫ��32�ֽڵ���������
		   2������봫������жϣ���ǰDMA����ʹ�û������ĺ�벿�֣��û����Բ���ǰ�벿�֡�
		*/
		
		DMA1->LIFCR = DMA_FLAG_HTIF0_4;
	}
	/* ��������ж� */
	if((DMA1->LISR & DMA_FLAG_TEIF0_4) != RESET)
	{
		/* �����־ */
		DMA1->LIFCR = DMA_FLAG_TEIF0_4;
	}

	/* ֱ��ģʽ�����ж� */
	if((DMA1->LISR & DMA_FLAG_DMEIF0_4) != RESET)
	{
		/* �����־ */
		DMA1->LIFCR = DMA_FLAG_DMEIF0_4;
	}
}

//void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* AdcHandle)   //ADC�ص����������ڶ�ȡADֵ
//{
//		uint32_t ADC_ConvertedValue = 0;
//        ADC_ConvertedValue = HAL_ADCEx_MultiModeGetValue(&hadc1);  
//        static int j = 0;
//        //ADC_convol1����ֵ����ڵ�16λ��ADC_convol2����ֵ����ڸ�16λ��            
//        ADC_ConvertedValue_1[i] = ADC_ConvertedValue;
//        ADC_ConvertedValue_2[i] = ADC_ConvertedValue >> 16;
//        j++;
//        if(j >= sample_counts)
//        {
//                j = 0;
//                HAL_TIM_Base_Stop(&htim6);
//                dma_flag = 1;
//        }
//               
//}

/* USER CODE END 1 */
