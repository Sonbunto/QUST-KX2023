#ifndef __BSPS_AD9280_H
#define __BSPS_AD9280_H


void bsps_ad9280_init(void);
void bsps_ad9280_sample_test(void);

#endif
