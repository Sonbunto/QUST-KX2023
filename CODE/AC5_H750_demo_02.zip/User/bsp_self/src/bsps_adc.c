#include "bsp.h"

/*
	ʵ�ֹ��ܣ�������ADC+DMA+TIM�Ĳ�������
	���·���ȱ�ݣ�PC0��Ӧ��ADC1_IN10��߽�֧��1Mps�����ʣ�������һ���иĽ�
*/

#define sample_counts 1024		//��������
#define tim6_psc 24-1			//��Ƶֵ
#define tim6_arr 10-1			//����ֵ
#define test 0					//DMA���δ���

//�������� ע��Ҫ����IRAM2�Σ������IRAM1����DMA�޷�����
ALIGN_32BYTES(__attribute__((section (".RAM_D1"))) uint16_t ADCxValues[sample_counts]);

__IO uint8_t dma_flag = 0;		//DMA������ɱ�־λ
uint16_t i = 0;					//��������

ADC_HandleTypeDef hadc1;
TIM_HandleTypeDef htim6;
DMA_HandleTypeDef hdma_adc1;

void bsps_adc1_init(void)
{
	ADC_MultiModeTypeDef multimode = {0};
	ADC_ChannelConfTypeDef sConfig = {0};
	
	hadc1.Instance = ADC1;
	hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;
	hadc1.Init.Resolution = ADC_RESOLUTION_16B;
	hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
	hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
	hadc1.Init.LowPowerAutoWait = DISABLE;
	hadc1.Init.ContinuousConvMode = DISABLE;
	hadc1.Init.NbrOfConversion = 1;
	hadc1.Init.DiscontinuousConvMode = DISABLE;
	hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIG_T6_TRGO;
	hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_FALLING;
	#if test == 1
		hadc1.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_ONESHOT;
	#else
		hadc1.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_CIRCULAR;
	#endif
	hadc1.Init.Overrun = ADC_OVR_DATA_OVERWRITTEN;
	hadc1.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
	hadc1.Init.OversamplingMode = DISABLE;
	if (HAL_ADC_Init(&hadc1) != HAL_OK)
	{
		Error_Handler(__FILE__, __LINE__);
	}
	
//	if (HAL_ADCEx_Calibration_Start(&hadc1, ADC_CALIB_OFFSET, ADC_SINGLE_ENDED) != HAL_OK)
//	{
//		Error_Handler(__FILE__, __LINE__);
//	}
	multimode.Mode = ADC_MODE_INDEPENDENT;
	if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
	{
		Error_Handler(__FILE__, __LINE__);
	}
	
	
	/** Configure Regular Channel
	*/
	sConfig.Channel = ADC_CHANNEL_10;
	sConfig.Rank = ADC_REGULAR_RANK_1;
	sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
	sConfig.SingleDiff = ADC_SINGLE_ENDED;
	sConfig.OffsetNumber = ADC_OFFSET_NONE;
	sConfig.Offset = 0;
	sConfig.OffsetSignedSaturation = DISABLE;
	if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
	{
		Error_Handler(__FILE__, __LINE__);
	}
}

//DMA�Լ�IO��ʼ�����˺����ᱻHAL_ADC_Init()����
void HAL_ADC_MspInit(ADC_HandleTypeDef* adcHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  RCC_PeriphCLKInitTypeDef PeriphClkInitStruct = {0};
  if(adcHandle->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspInit 0 */

  /* USER CODE END ADC1_MspInit 0 */

  /** Initializes the peripherals clock
  */
    PeriphClkInitStruct.PeriphClockSelection = RCC_PERIPHCLK_ADC;
    PeriphClkInitStruct.PLL2.PLL2M = 25;
    PeriphClkInitStruct.PLL2.PLL2N = 504;
    PeriphClkInitStruct.PLL2.PLL2P = 7;
    PeriphClkInitStruct.PLL2.PLL2Q = 2;
    PeriphClkInitStruct.PLL2.PLL2R = 2;
    PeriphClkInitStruct.PLL2.PLL2RGE = RCC_PLL2VCIRANGE_0;
    PeriphClkInitStruct.PLL2.PLL2VCOSEL = RCC_PLL2VCOWIDE;
    PeriphClkInitStruct.PLL2.PLL2FRACN = 0;
    PeriphClkInitStruct.AdcClockSelection = RCC_ADCCLKSOURCE_PLL2;
    if (HAL_RCCEx_PeriphCLKConfig(&PeriphClkInitStruct) != HAL_OK)
    {
      Error_Handler(__FILE__, __LINE__);
    }

    /* ADC1 clock enable */
    __HAL_RCC_ADC12_CLK_ENABLE();
	__HAL_RCC_DMA1_CLK_ENABLE();
    __HAL_RCC_GPIOC_CLK_ENABLE();
    /**ADC1 GPIO Configuration
    PC0     ------> ADC1_INP10
    */
    GPIO_InitStruct.Pin = GPIO_PIN_0;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

    /* ADC1 DMA Init */
    /* ADC1 Init */
    hdma_adc1.Instance = DMA1_Stream1;
    hdma_adc1.Init.Request = DMA_REQUEST_ADC1;
    hdma_adc1.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc1.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
	#if test == 1
		hdma_adc1.Init.Mode = DMA_NORMAL;
	#else
		hdma_adc1.Init.Mode = DMA_CIRCULAR;
	#endif
    hdma_adc1.Init.Priority = DMA_PRIORITY_LOW;
    hdma_adc1.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    if (HAL_DMA_Init(&hdma_adc1) != HAL_OK)
    {
      Error_Handler(__FILE__, __LINE__);
    }
		
	HAL_NVIC_SetPriority(DMA1_Stream1_IRQn, 2, 0);
	HAL_NVIC_EnableIRQ(DMA1_Stream1_IRQn);

    __HAL_LINKDMA(adcHandle,DMA_Handle,hdma_adc1);

  /* USER CODE BEGIN ADC1_MspInit 1 */

  /* USER CODE END ADC1_MspInit 1 */
  }
}

void bsps_tim6_init(void)
{
	TIM_MasterConfigTypeDef sMasterConfig = {0};
	
	__HAL_RCC_TIM6_CLK_ENABLE();
	
	htim6.Instance = TIM6;
	htim6.Init.Prescaler = tim6_psc;
	htim6.Init.CounterMode = TIM_COUNTERMODE_UP;
	htim6.Init.Period = tim6_arr;
	htim6.Init.AutoReloadPreload = TIM_AUTORELOAD_PRELOAD_DISABLE;
	if (HAL_TIM_Base_Init(&htim6) != HAL_OK)
	{
		Error_Handler(__FILE__, __LINE__);
	}
	sMasterConfig.MasterOutputTrigger = TIM_TRGO_UPDATE;
	sMasterConfig.MasterSlaveMode = TIM_MASTERSLAVEMODE_DISABLE;
	if (HAL_TIMEx_MasterConfigSynchronization(&htim6, &sMasterConfig) != HAL_OK)
	{
		Error_Handler(__FILE__, __LINE__);
	}
}

void bsps_sample_test(void)
{
	if(dma_flag)
	{
//		DISABLE_INT();
		for(i = 0;i < sample_counts;i++)
		{
			printf("%.3f\r\n",3.3f*ADCxValues[i]/65535.0f);
		}
		dma_flag = 0;
//		ENABLE_INT();
	}   
}


void bsps_adc_init(void)
{
	bsps_adc1_init();
	bsps_tim6_init();
}

void bsps_adc_sample_start(void)
{
	if (HAL_TIM_Base_Start(&htim6) != HAL_OK)
	{
		Error_Handler(__FILE__, __LINE__);
	}
	if (HAL_ADC_Start_DMA(&hadc1, (uint32_t *)ADCxValues, sample_counts) != HAL_OK)
	{
		Error_Handler(__FILE__, __LINE__);
	}
}


void DMA1_Stream1_IRQHandler(void)
{
	/* ��������ж� */
	if((DMA1->LISR & DMA_FLAG_TCIF1_5) != RESET)
	{
		/*
		   1��ʹ�ô˺���Ҫ�ر�ע�⣬��1��������ַҪ32�ֽڶ��룬��2������Ҫ��32�ֽڵ���������
		   2�����봫������жϣ���ǰDMA����ʹ�û�������ǰ�벿�֣��û����Բ�����벿�֡�
		*/
		SCB_CleanInvalidateDCache();
		
		dma_flag = 1;
		
		DMA1->LIFCR = DMA_FLAG_TCIF1_5;
	}

	/* �봫������ж� */    
	if((DMA1->LISR & DMA_FLAG_HTIF1_5) != RESET)
	{
		DMA1->LIFCR = DMA_FLAG_HTIF1_5;
	}
	/* ��������ж� */
	if((DMA1->LISR & DMA_FLAG_TEIF1_5) != RESET)
	{
		DMA1->LIFCR = DMA_FLAG_TEIF1_5;
	}

	/* ֱ��ģʽ�����ж� */
	if((DMA1->LISR & DMA_FLAG_DMEIF1_5) != RESET)
	{
		DMA1->LIFCR = DMA_FLAG_DMEIF1_5;
	}
}



