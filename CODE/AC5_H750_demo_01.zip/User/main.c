#include "bsp.h"		


int main(void)
{
	bsp_Init();	
//	bsps_adc_sample_start();

	while (1)
	{
		bsps_ad9280_sample_test();
//		EventStartA(0);
//		bsps_sample_test();
//		EventStopA(0);
//		bsp_Idle();
//		EventStartA(1);
//		EventStopA(1);
	}
}


