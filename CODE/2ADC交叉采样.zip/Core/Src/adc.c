/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file    adc.c
  * @brief   This file provides code for the configuration
  *          of the ADC instances.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "adc.h"

/* USER CODE BEGIN 0 */
#include "stdio.h"
#include "tim.h"

#define sample_counts 128

__IO uint8_t dma_flag = 0;
uint16_t i = 0;

ALIGN_32BYTES(__attribute__((section (".RAM_D1"))) uint32_t ADC_ConvertedValue[sample_counts]);

ALIGN_32BYTES(__attribute__((section (".RAM_D1"))) uint16_t ADC_ConvertedValue_1[sample_counts]);
ALIGN_32BYTES(__attribute__((section (".RAM_D1"))) uint16_t ADC_ConvertedValue_2[sample_counts]);

/* USER CODE END 0 */

ADC_HandleTypeDef hadc1;
ADC_HandleTypeDef hadc2;
DMA_HandleTypeDef hdma_adc1;
DMA_HandleTypeDef hdma_adc2;

/* ADC1 init function */
void MX_ADC1_Init(void)
{

  /* USER CODE BEGIN ADC1_Init 0 */

  /* USER CODE END ADC1_Init 0 */

  ADC_MultiModeTypeDef multimode = {0};
  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC1_Init 1 */
  
  

  /* USER CODE END ADC1_Init 1 */

  /** Common config
  */
  hadc1.Instance = ADC1;
  hadc1.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;
  hadc1.Init.Resolution = ADC_RESOLUTION_8B;
  hadc1.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc1.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc1.Init.LowPowerAutoWait = DISABLE;
  hadc1.Init.ContinuousConvMode = DISABLE;
  hadc1.Init.NbrOfConversion = 1;
  hadc1.Init.DiscontinuousConvMode = DISABLE;
  hadc1.Init.ExternalTrigConv = ADC_EXTERNALTRIG_T6_TRGO;
  hadc1.Init.ExternalTrigConvEdge = ADC_EXTERNALTRIGCONVEDGE_FALLING;
  hadc1.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_ONESHOT;
  hadc1.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc1.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
  hadc1.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure the ADC multi-mode
  */
  multimode.Mode = ADC_DUALMODE_ALTERTRIG;
  multimode.DualModeData = ADC_DUALMODEDATAFORMAT_32_10_BITS;
  multimode.TwoSamplingDelay = ADC_TWOSAMPLINGDELAY_1CYCLE;
  if (HAL_ADCEx_MultiModeConfigChannel(&hadc1, &multimode) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  sConfig.OffsetSignedSaturation = DISABLE;
  if (HAL_ADC_ConfigChannel(&hadc1, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC1_Init 2 */

  /* USER CODE END ADC1_Init 2 */

}
/* ADC2 init function */
void MX_ADC2_Init(void)
{

  /* USER CODE BEGIN ADC2_Init 0 */
	

  /* USER CODE END ADC2_Init 0 */

  ADC_ChannelConfTypeDef sConfig = {0};

  /* USER CODE BEGIN ADC2_Init 1 */
  

  /* USER CODE END ADC2_Init 1 */

  /** Common config
  */
  hadc2.Instance = ADC2;
  hadc2.Init.ClockPrescaler = ADC_CLOCK_ASYNC_DIV2;
  hadc2.Init.Resolution = ADC_RESOLUTION_16B;
  hadc2.Init.ScanConvMode = ADC_SCAN_DISABLE;
  hadc2.Init.EOCSelection = ADC_EOC_SINGLE_CONV;
  hadc2.Init.LowPowerAutoWait = DISABLE;
  hadc2.Init.ContinuousConvMode = DISABLE;
  hadc2.Init.NbrOfConversion = 1;
  hadc2.Init.DiscontinuousConvMode = DISABLE;
  hadc2.Init.ConversionDataManagement = ADC_CONVERSIONDATA_DMA_ONESHOT;
  hadc2.Init.Overrun = ADC_OVR_DATA_PRESERVED;
  hadc2.Init.LeftBitShift = ADC_LEFTBITSHIFT_NONE;
  hadc2.Init.OversamplingMode = DISABLE;
  if (HAL_ADC_Init(&hadc2) != HAL_OK)
  {
    Error_Handler();
  }

  /** Configure Regular Channel
  */
  sConfig.Channel = ADC_CHANNEL_3;
  sConfig.Rank = ADC_REGULAR_RANK_1;
  sConfig.SamplingTime = ADC_SAMPLETIME_1CYCLE_5;
  sConfig.SingleDiff = ADC_SINGLE_ENDED;
  sConfig.OffsetNumber = ADC_OFFSET_NONE;
  sConfig.Offset = 0;
  sConfig.OffsetSignedSaturation = DISABLE;
  if (HAL_ADC_ConfigChannel(&hadc2, &sConfig) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN ADC2_Init 2 */

  /* USER CODE END ADC2_Init 2 */

}

static uint32_t HAL_RCC_ADC12_CLK_ENABLED=0;

void HAL_ADC_MspInit(ADC_HandleTypeDef* adcHandle)
{

  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(adcHandle->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspInit 0 */

  /* USER CODE END ADC1_MspInit 0 */
    /* ADC1 clock enable */
    HAL_RCC_ADC12_CLK_ENABLED++;
    if(HAL_RCC_ADC12_CLK_ENABLED==1){
      __HAL_RCC_ADC12_CLK_ENABLE();
    }

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**ADC1 GPIO Configuration
    PA6     ------> ADC1_INP3
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* ADC1 DMA Init */
    /* ADC1 Init */
    hdma_adc1.Instance = DMA1_Stream0;
    hdma_adc1.Init.Request = DMA_REQUEST_ADC1;
    hdma_adc1.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc1.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc1.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc1.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc1.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_adc1.Init.Mode = DMA_NORMAL;
    hdma_adc1.Init.Priority = DMA_PRIORITY_LOW;
    hdma_adc1.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    if (HAL_DMA_Init(&hdma_adc1) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(adcHandle,DMA_Handle,hdma_adc1);

  /* USER CODE BEGIN ADC1_MspInit 1 */

  /* USER CODE END ADC1_MspInit 1 */
  }
  else if(adcHandle->Instance==ADC2)
  {
  /* USER CODE BEGIN ADC2_MspInit 0 */

  /* USER CODE END ADC2_MspInit 0 */
    /* ADC2 clock enable */
    HAL_RCC_ADC12_CLK_ENABLED++;
    if(HAL_RCC_ADC12_CLK_ENABLED==1){
      __HAL_RCC_ADC12_CLK_ENABLE();
    }

    __HAL_RCC_GPIOA_CLK_ENABLE();
    /**ADC2 GPIO Configuration
    PA6     ------> ADC2_INP3
    */
    GPIO_InitStruct.Pin = GPIO_PIN_6;
    GPIO_InitStruct.Mode = GPIO_MODE_ANALOG;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

    /* ADC2 DMA Init */
    /* ADC2 Init */
    hdma_adc2.Instance = DMA2_Stream0;
    hdma_adc2.Init.Request = DMA_REQUEST_ADC2;
    hdma_adc2.Init.Direction = DMA_PERIPH_TO_MEMORY;
    hdma_adc2.Init.PeriphInc = DMA_PINC_DISABLE;
    hdma_adc2.Init.MemInc = DMA_MINC_ENABLE;
    hdma_adc2.Init.PeriphDataAlignment = DMA_PDATAALIGN_HALFWORD;
    hdma_adc2.Init.MemDataAlignment = DMA_MDATAALIGN_HALFWORD;
    hdma_adc2.Init.Mode = DMA_NORMAL;
    hdma_adc2.Init.Priority = DMA_PRIORITY_LOW;
    hdma_adc2.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
    if (HAL_DMA_Init(&hdma_adc2) != HAL_OK)
    {
      Error_Handler();
    }

    __HAL_LINKDMA(adcHandle,DMA_Handle,hdma_adc2);

  /* USER CODE BEGIN ADC2_MspInit 1 */

  /* USER CODE END ADC2_MspInit 1 */
  }
}

void HAL_ADC_MspDeInit(ADC_HandleTypeDef* adcHandle)
{

  if(adcHandle->Instance==ADC1)
  {
  /* USER CODE BEGIN ADC1_MspDeInit 0 */

  /* USER CODE END ADC1_MspDeInit 0 */
    /* Peripheral clock disable */
    HAL_RCC_ADC12_CLK_ENABLED--;
    if(HAL_RCC_ADC12_CLK_ENABLED==0){
      __HAL_RCC_ADC12_CLK_DISABLE();
    }

    /**ADC1 GPIO Configuration
    PA6     ------> ADC1_INP3
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_6);

    /* ADC1 DMA DeInit */
    HAL_DMA_DeInit(adcHandle->DMA_Handle);
  /* USER CODE BEGIN ADC1_MspDeInit 1 */

  /* USER CODE END ADC1_MspDeInit 1 */
  }
  else if(adcHandle->Instance==ADC2)
  {
  /* USER CODE BEGIN ADC2_MspDeInit 0 */

  /* USER CODE END ADC2_MspDeInit 0 */
    /* Peripheral clock disable */
    HAL_RCC_ADC12_CLK_ENABLED--;
    if(HAL_RCC_ADC12_CLK_ENABLED==0){
      __HAL_RCC_ADC12_CLK_DISABLE();
    }

    /**ADC2 GPIO Configuration
    PA6     ------> ADC2_INP3
    */
    HAL_GPIO_DeInit(GPIOA, GPIO_PIN_6);

    /* ADC2 DMA DeInit */
    HAL_DMA_DeInit(adcHandle->DMA_Handle);
  /* USER CODE BEGIN ADC2_MspDeInit 1 */

  /* USER CODE END ADC2_MspDeInit 1 */
  }
}

/* USER CODE BEGIN 1 */

void Start_DMA_ADC(void)
{
//	if (HAL_ADC_Start_DMA(&hadc1, (uint32_t *)ADCxValues, sample_counts) != HAL_OK)
//	{
//		Error_Handler();
//	}
//	HAL_ADC_Start(&hadc2);
//	HAL_ADC_Start(&hadc1);
	if (HAL_TIM_Base_Start(&htim6) != HAL_OK)
	{
		Error_Handler();
	}
	if(HAL_ADCEx_MultiModeStart_DMA(&hadc1, (uint32_t*)&ADC_ConvertedValue, sample_counts * 2) != HAL_OK)
	{
		Error_Handler();
	}
	
}



void sample_data(void)
{
	uint32_t values;
	float  temp;
	
	/* ��ǰDMA�����Ǻ������壬��ȡǰ��������ǰ4����ֵ��ƽ�� */
	if(dma_flag)
	{
		__set_PRIMASK(1);
		for(i = 0;i < sample_counts;i++)
		{
			ADC_ConvertedValue_1[i] = ADC_ConvertedValue[i];
			ADC_ConvertedValue_2[i] = ADC_ConvertedValue[i] >> 16;
		}
		for(i = 0;i < sample_counts;i++)
		{
			printf("%.3f\r\n",ADC_ConvertedValue_1[i] * 3.3f / 256.0f);
			printf("%.3f\r\n",ADC_ConvertedValue_2[i] * 3.3f / 256.0f);
		}
		dma_flag = 0;
		__set_PRIMASK(0);
//		HAL_ADC_Stop_DMA(&hadc1);
		HAL_TIM_Base_Stop(&htim6);
	}
}
void DMA1_Stream0_IRQHandler(void)
{
	/* ��������ж� */
	if((DMA1->LISR & DMA_FLAG_TCIF0_4) != RESET)
	{
		/*
		   1��ʹ�ô˺���Ҫ�ر�ע�⣬��1��������ַҪ32�ֽڶ��룬��2������Ҫ��32�ֽڵ���������
		   2�����봫������жϣ���ǰDMA����ʹ�û�������ǰ�벿�֣��û����Բ�����벿�֡�
		*/
		SCB_CleanInvalidateDCache();
		
		dma_flag = 1;
		
		/* �����־ */
		DMA1->LIFCR = DMA_FLAG_TCIF0_4;
	}

/* �봫������ж� */    
	if((DMA1->LISR & DMA_FLAG_HTIF0_4) != RESET)
	{
		/*
		   1��ʹ�ô˺���Ҫ�ر�ע�⣬��1��������ַҪ32�ֽڶ��룬��2������Ҫ��32�ֽڵ���������
		   2������봫������жϣ���ǰDMA����ʹ�û������ĺ�벿�֣��û����Բ���ǰ�벿�֡�
		*/
		
		DMA1->LIFCR = DMA_FLAG_HTIF0_4;
	}
	/* ��������ж� */
	if((DMA1->LISR & DMA_FLAG_TEIF0_4) != RESET)
	{
		/* �����־ */
		DMA1->LIFCR = DMA_FLAG_TEIF0_4;
	}

	/* ֱ��ģʽ�����ж� */
	if((DMA1->LISR & DMA_FLAG_DMEIF0_4) != RESET)
	{
		/* �����־ */
		DMA1->LIFCR = DMA_FLAG_DMEIF0_4;
	}
}

void DMA2_Stream0_IRQHandler(void)
{
	/* ��������ж� */
	if((DMA2->LISR & DMA_FLAG_TCIF0_4) != RESET)
	{
		/*
		   1��ʹ�ô˺���Ҫ�ر�ע�⣬��1��������ַҪ32�ֽڶ��룬��2������Ҫ��32�ֽڵ���������
		   2�����봫������жϣ���ǰDMA����ʹ�û�������ǰ�벿�֣��û����Բ�����벿�֡�
		*/
		SCB_CleanInvalidateDCache();
		
//		dma_flag = 1;
		
		/* �����־ */
		DMA2->LIFCR = DMA_FLAG_TCIF0_4;
	}

/* �봫������ж� */    
	if((DMA2->LISR & DMA_FLAG_HTIF0_4) != RESET)
	{
		/*
		   1��ʹ�ô˺���Ҫ�ر�ע�⣬��1��������ַҪ32�ֽڶ��룬��2������Ҫ��32�ֽڵ���������
		   2������봫������жϣ���ǰDMA����ʹ�û������ĺ�벿�֣��û����Բ���ǰ�벿�֡�
		*/
		
		DMA2->LIFCR = DMA_FLAG_HTIF0_4;
	}
	/* ��������ж� */
	if((DMA2->LISR & DMA_FLAG_TEIF0_4) != RESET)
	{
		/* �����־ */
		DMA2->LIFCR = DMA_FLAG_TEIF0_4;
	}

	/* ֱ��ģʽ�����ж� */
	if((DMA2->LISR & DMA_FLAG_DMEIF0_4) != RESET)
	{
		/* �����־ */
		DMA2->LIFCR = DMA_FLAG_DMEIF0_4;
	}
}

//void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* AdcHandle)   //ADC�ص����������ڶ�ȡADֵ
//{
//		uint32_t ADC_ConvertedValue = 0;
//        ADC_ConvertedValue = HAL_ADCEx_MultiModeGetValue(&hadc1);  
//        static int j = 0;
//        //ADC_convol1����ֵ����ڵ�16λ��ADC_convol2����ֵ����ڸ�16λ��            
//        ADC_ConvertedValue_1[i] = ADC_ConvertedValue;
//        ADC_ConvertedValue_2[i] = ADC_ConvertedValue >> 16;
//        j++;
//        if(j >= sample_counts)
//        {
//                j = 0;
//                HAL_TIM_Base_Stop(&htim6);
//                dma_flag = 1;
//        }
//               
//}

/* USER CODE END 1 */
